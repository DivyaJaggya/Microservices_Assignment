package com.amdocs.authorization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.authorization.model.Credential;
import com.amdocs.authorization.model.ResponseObject;
import com.amdocs.authorization.service.LoginService;

@RestController
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	@PostMapping
	public ResponseEntity<ResponseObject> authentication(@RequestBody(required = false) Credential credential) {
		ResponseObject ro = loginService.authenticationService(credential);
		if ("0".equalsIgnoreCase(ro.getCode())) {
			return new ResponseEntity<>(ro, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(ro,HttpStatus.NOT_FOUND);
		}	
	}
	

}
