package com.amdocs.authorization.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdocs.authorization.dao.CredentialRepository;
import com.amdocs.authorization.model.Credential;
import com.amdocs.authorization.model.ResponseObject;

@Service
public class LoginService {
	
	@Autowired
	CredentialRepository credentialRepository;
	
	public ResponseObject authenticationService(Credential credential) {
		
		ResponseObject rs = new ResponseObject();

		Credential presentDatainDB = credentialRepository.findByUsername(credential.getUsername());
		
		if(presentDatainDB==null) {
			 rs.setCode("1");
			 rs.setMessage("Username Doesnt exsists");
			return rs;	
		} 
		
		if(!presentDatainDB.getPassword().equalsIgnoreCase(credential.getPassword())) {
			 rs.setCode("1");
			 rs.setMessage("username/password Doesn't match");
			return rs;
		} 
		
			 rs.setCode("0");
			 rs.setMessage("User found successfully");
			return rs;
		}
		
}
	
	
