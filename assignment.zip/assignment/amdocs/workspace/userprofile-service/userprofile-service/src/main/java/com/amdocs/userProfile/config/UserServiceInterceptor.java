package com.amdocs.userProfile.config;

import java.util.Collections;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.UriSpec;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.ContentCachingRequestWrapper;

import com.amdocs.userProfile.exception.UserNotVerifiedException;
import com.amdocs.userProfile.model.Credential;
import com.amdocs.userProfile.model.Profile;
import com.amdocs.userProfile.model.ResponseObject;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import reactor.core.publisher.Mono;

@Component
public class UserServiceInterceptor implements HandlerInterceptor {
	
	private final WebClient webClient;
	
	public UserServiceInterceptor(WebClient.Builder webClientBuilder) {
		this.webClient = WebClient.builder()
				  .baseUrl("http://localhost:8082")
				  .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE) 
				  .defaultUriVariables(Collections.singletonMap("url", "http://localhost:8082/"))
				  .build();
	}
	
	/*
	 * public String getFallBackInfo() throws Exception { throw new
	 * Exception("Authoriuzation Server is down, please try again later "); }
	 */

	
	 @Override
	// @HystrixCommand(fallbackMethod = "getFallBackInfo")
	   public boolean preHandle
	      (HttpServletRequest request, HttpServletResponse response, Object handler) 
	      throws Exception {
	      
	      System.out.println("Pre Handle method is Calling");
	      
	      UriSpec<RequestBodySpec> uriSpec = webClient.method(HttpMethod.POST);
	      RequestBodySpec bodySpec = uriSpec.uri(
	    		  uriBuilder -> uriBuilder.pathSegment("login").build());
	      
	      ObjectMapper mapper = new ObjectMapper();
	      Profile profile = mapper.readValue(request.getInputStream(),Profile.class);
	      
	      ServletRequest servletRequest = new ContentCachingRequestWrapper(request);
	      servletRequest.getParameterMap();
	      
	      Credential credential = new Credential();
	      credential.setUsername(profile.getUsername());
	      credential.setPassword(profile.getPassword());
	      RequestHeadersSpec<?> headersSpec = bodySpec.body(
	    		  Mono.just(credential), Credential.class);
	    //  Mono<String> verificationResponse = headersSpec.retrieve()
	    	//	  .bodyToMono(String.class);
	      
	      Mono<String> verificationResponse = headersSpec.exchangeToMono(Response -> {
	    	  if (Response.statusCode()
	    	    .equals(HttpStatus.OK)) {
	    	      return Response.bodyToMono(String.class);
	    	  } else if (Response.statusCode()
	    	    .is4xxClientError()) {
	    	      return Mono.just("400");
	    	  } else {
	    	      return Mono.just("500");
	    	  }
	    	});
	      
	      String strResp = verificationResponse.block();
	      if(strResp=="400") {
	    	  throw new UserNotVerifiedException("Either User Not Registered or entered Credentials are invalid");
	      }
	      if(strResp=="500") {
	    	  throw new UserNotVerifiedException("Currently our systems are not up. Try again later ! ");
	      }
	      ObjectMapper mapperverification = new ObjectMapper();
	      ResponseObject rs = mapperverification.readValue(strResp,ResponseObject.class);
	      System.out.println("Pre Handle call completed" + rs.toString());
	      return true;
	   }

	 @Override
	    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception
	    {
	        System.out.println("MINIMAL: INTERCEPTOR POSTHANDLE CALLED");
	    }

	    @Override
	    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception exception) throws Exception
	    {
	        System.out.println("MINIMAL: INTERCEPTOR AFTERCOMPLETION CALLED");
	    }
	    
	    
	    
}
