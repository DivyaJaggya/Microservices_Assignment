package com.amdocs.userProfile.exception;

public class UserNotVerifiedException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	  public UserNotVerifiedException(String msg) {
	    super(msg);
	  }
}
