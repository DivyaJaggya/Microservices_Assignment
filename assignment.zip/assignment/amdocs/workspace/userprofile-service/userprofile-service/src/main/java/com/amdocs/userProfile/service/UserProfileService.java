package com.amdocs.userProfile.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdocs.userProfile.dao.UserRepository;
import com.amdocs.userProfile.model.Profile;
import com.amdocs.userProfile.model.ResponseObject;

@Service
public class UserProfileService {
	
	@Autowired
	UserRepository userRepository;
	
	public ResponseObject createService(Profile profile) {
		
		ResponseObject rs = new ResponseObject();
		
		 Optional<Profile> DatainDB = userRepository.findByUsername(profile.getUsername());
		 
		 if(DatainDB.isPresent()) {
			 rs.setCode("1");
			 rs.setMessage("User already Exists");
			return rs;	
		}

		Profile presentDatainDB = userRepository.save(profile);
		
		if(presentDatainDB==null) {
			 rs.setCode("1");
			 rs.setMessage("User was not added due to server issue.Please try again later");
			return rs;	
		} 
		
			 rs.setCode("0");
			 rs.setMessage("User added successfully");
			return rs;
		}
	
	public ResponseObject updateService(Profile profile) throws Exception{
		
		ResponseObject rs = new ResponseObject();

		 Optional<Profile> presentDatainDB = userRepository.findByUsername(profile.getUsername());
		
		if(!presentDatainDB.isPresent()) {
			 rs.setCode("1");
			 rs.setMessage("User doesn't Exists");
			return rs;	
		} else {
			Profile updatedProfile = new Profile();
			updatedProfile.setUsername(profile.getUsername());
			updatedProfile.setPhone_no(profile.getPhone_no());
			updatedProfile.setPassword(profile.getPassword());
			updatedProfile.setAddress(profile.getAddress());
			Profile presentupdatedDatainDB = userRepository.save(updatedProfile);
			if(presentupdatedDatainDB==null) {
				 rs.setCode("1");
				 rs.setMessage("User details were not updated successfully.Please try again later");
				return rs;	
			} 
		}
		
			 rs.setCode("0");
			 rs.setMessage("User information got updated successfully");
			return rs;
	}
	
    public ResponseObject deleteService(Profile profile) throws Exception{
		
		ResponseObject rs = new ResponseObject();

		 Optional<Profile> presentDatainDB = userRepository.findByUsername(profile.getUsername());
		
		if(!presentDatainDB.isPresent()) {
			 rs.setCode("1");
			 rs.setMessage("User doesn't Exists");
			return rs;	
		} else {
			userRepository.delete(presentDatainDB.get()); 
		}
			 rs.setCode("0");
			 rs.setMessage("User information got deleted successfully");
			return rs;
		}
		
}
	
	
