package com.amdocs.userProfile.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.amdocs.userProfile.model.Profile;

public interface UserRepository extends JpaRepository<Profile, String> {

	Optional<Profile> findByUsername(String username);
	
}
