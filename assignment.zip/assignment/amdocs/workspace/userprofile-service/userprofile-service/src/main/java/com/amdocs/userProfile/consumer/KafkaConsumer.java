package com.amdocs.userProfile.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import com.amdocs.userProfile.constant.ApplicationConstant;
import com.amdocs.userProfile.model.Profile;
import com.amdocs.userProfile.model.ResponseObject;
import com.amdocs.userProfile.service.UserProfileService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class KafkaConsumer {

	private static final Logger logger = LoggerFactory.getLogger(KafkaConsumer.class);
	
	@Autowired
	UserProfileService userProfileService;

	@KafkaListener(groupId = ApplicationConstant.GROUP_ID_JSON, topics = ApplicationConstant.TOPIC_NAME, containerFactory = ApplicationConstant.KAFKA_LISTENER_CONTAINER_FACTORY)
	public void receivedProfileForUpdate(Profile profile, Acknowledgment acknowledgment) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String profileString = mapper.writeValueAsString(profile);
		logger.info("Json message received using Kafka listener " + profileString);
		ResponseObject ro;
		try {
			ro = userProfileService.updateService(profile);
		} catch (Exception e) {
			System.out.println("Exception in Database");
			throw new Exception("User details were not updated successfully.Please try again later");
		}
		  if("0".equalsIgnoreCase(ro.getCode())) {
			  acknowledgment.acknowledge();
			  }		
	}
	
	@KafkaListener(groupId = ApplicationConstant.GROUP_ID_JSON, topics = ApplicationConstant.DELETE_TOPIC_NAME, containerFactory = ApplicationConstant.KAFKA_LISTENER_CONTAINER_FACTORY)
	public void receivedProfileForDelete(Profile profile, Acknowledgment acknowledgment) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String profileString = mapper.writeValueAsString(profile);
		logger.info("Json message received using Kafka listener " + profileString);
		ResponseObject ro;
		try {
			ro = userProfileService.deleteService(profile);
		} catch (Exception e) {
			System.out.println("Exception in Database");
			throw new Exception("User details were not updated successfully.Please try again later");
		}
		  if("0".equalsIgnoreCase(ro.getCode())) {
			  acknowledgment.acknowledge();
			  }		
	}
}
