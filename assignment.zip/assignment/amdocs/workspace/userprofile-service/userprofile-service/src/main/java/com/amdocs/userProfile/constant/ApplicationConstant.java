package com.amdocs.userProfile.constant;

public class ApplicationConstant {
	public static final String KAFKA_LOCAL_SERVER_CONFIG = "localhost:9092";
	public static final String GROUP_ID_STRING = "groupId-string-1";
	public static final String TOPIC_NAME = "assignment-topic-1";
	public static final String DELETE_TOPIC_NAME = "assignment-delete-topic-1";
	public static final String KAFKA_LISTENER_CONTAINER_FACTORY = "kafkaListenerContainerFactory";
	public static final String GROUP_ID_JSON = "groupId-json-1";
	public static final String ACKS_MODE = "all";
	public static final String INSYNC_REPLICA_TIME = "5";
	public static final String MIN_INSYNC_REPLICA = "2";
	public static final String RETRIES = "5";
}
