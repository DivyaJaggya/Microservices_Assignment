package com.amdocs.userProfile.model;

import javax.persistence.*;
/**
 * @author divya
 *
 */
@Entity
@Table(name = "user_profile")
public class Profile {
	
		
		@GeneratedValue(strategy = GenerationType.AUTO)
		private long id;

		@Id
		@Column(name = "username")
		private String username;

		@Column(name = "address")
		private String address;
		
		@Column(name = "password")
		private String password;
		
		@Column(name = "phone_no")
		private int phone_no;

		public Profile() {

		}

		public Profile(String username, String address, int phone_no,String password) {
			this.username = username;
			this.address = address;
			this.phone_no = phone_no;
			this.password = password;
		}

		@Override
		public String toString() {
			return "user_profile [id=" + id + ", username=" + username + ", address=" + address + ", phone_no=" + phone_no + "]";
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public int getPhone_no() {
			return phone_no;
		}

		public void setPhone_no(int phone_no) {
			this.phone_no = phone_no;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		
		

}
