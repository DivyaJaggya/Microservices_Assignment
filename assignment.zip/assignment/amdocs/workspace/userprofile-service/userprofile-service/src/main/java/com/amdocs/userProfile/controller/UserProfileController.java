package com.amdocs.userProfile.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.ContentCachingRequestWrapper;

import com.amdocs.userProfile.constant.ApplicationConstant;
import com.amdocs.userProfile.model.Profile;
import com.amdocs.userProfile.model.ResponseObject;
import com.amdocs.userProfile.service.UserProfileService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/profile")
public class UserProfileController {
	
	@Autowired
	UserProfileService userProfileService;

	@Autowired
	private KafkaTemplate<String, Object> kafkaTemplate;
	
	@GetMapping
	public String applicationcheck() {
		return "endpoints Works";
	}
	
	@PostMapping
	public ResponseEntity<ResponseObject> create(@RequestBody(required = false) Profile profile,HttpServletRequest request) {
		
		 ContentCachingRequestWrapper requestWrapper = (ContentCachingRequestWrapper) request;
		 String requestBody = new String(requestWrapper.getContentAsByteArray());
		 ObjectMapper mapper = new ObjectMapper();
		 Profile profileCached = new Profile();
	      try {
			profileCached = mapper.readValue(requestBody,Profile.class);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	         

		ResponseObject ro = userProfileService.createService(profileCached);
		if ("0".equalsIgnoreCase(ro.getCode())) {
			return new ResponseEntity<>(ro, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(ro,HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}
	
	@PutMapping
	public ResponseEntity<ResponseObject> update(HttpServletRequest httpServletRequest,@RequestBody(required = false) Profile profile) throws Exception {

		ContentCachingRequestWrapper requestWrapper = (ContentCachingRequestWrapper) httpServletRequest;
		 String requestBody = new String(requestWrapper.getContentAsByteArray());
		 ObjectMapper mapper = new ObjectMapper();
		 Profile profileCached = new Profile();
	      try {
			profileCached = mapper.readValue(requestBody,Profile.class);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		 /* ResponseObject ro = userProfileService.updateService(profileCached);
		  if("0".equalsIgnoreCase(ro.getCode())) {
			  return new ResponseEntity<>(ro,HttpStatus.OK); 
			  } else { 
				  return new ResponseEntity<>(ro,HttpStatus.INTERNAL_SERVER_ERROR); 
			}*/
		 
	      
	      try {
				kafkaTemplate.send(ApplicationConstant.TOPIC_NAME, profileCached);
			} catch (Exception e) {
				System.out.println("Exception in Kafka");
				throw new Exception("User details were not updated successfully.Please try again later");
			}
	      
	         ResponseObject rs = new ResponseObject();
			 rs.setCode("0");
			 rs.setMessage("User information got updated successfully");
			 return new ResponseEntity<>(rs,HttpStatus.OK); 
		
	}
	
	@DeleteMapping
	public ResponseEntity<ResponseObject> delete(HttpServletRequest httpServletRequest,@RequestBody(required = false) Profile profile) throws Exception {
		
		ContentCachingRequestWrapper requestWrapper = (ContentCachingRequestWrapper) httpServletRequest;
		 String requestBody = new String(requestWrapper.getContentAsByteArray());
		 ObjectMapper mapper = new ObjectMapper();
		 Profile profileCached = new Profile();
	      try {
			profileCached = mapper.readValue(requestBody,Profile.class);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		/*ResponseObject ro = userProfileService.deleteService(profileCached);
		if ("0".equalsIgnoreCase(ro.getCode())) {
			return new ResponseEntity<>(ro, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(ro,HttpStatus.INTERNAL_SERVER_ERROR);
		}*/	
	      
	      try {
				kafkaTemplate.send(ApplicationConstant.DELETE_TOPIC_NAME, profileCached);
			} catch (Exception e) {
				System.out.println("Exception in Kafka");
				throw new Exception("User details were not deleted successfully.Please try again later");
			}
	      
	         ResponseObject rs = new ResponseObject();
			 rs.setCode("0");
			 rs.setMessage("User information got deleted successfully");
			 return new ResponseEntity<>(rs,HttpStatus.OK); 
	}
	

}
