package com.amdocs.userProfile.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ExceptionHandlers extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(value = UserNotVerifiedException.class)
	public ResponseEntity<ErrorMessage> exception(UserNotVerifiedException exception, WebRequest request) {
		
		 ErrorMessage message = new ErrorMessage(
				 exception.getMessage(),
			        "1");
			    
			    return new ResponseEntity<ErrorMessage>(message, HttpStatus.NOT_FOUND);
			  }
	
	@ExceptionHandler(Exception.class)
	  public ResponseEntity<ErrorMessage> globalExceptionHandler(Exception ex, WebRequest request) {
	    ErrorMessage message = new ErrorMessage(
	        ex.getMessage(),
	        "1");
	    
	    return new ResponseEntity<ErrorMessage>(message, HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	

}
